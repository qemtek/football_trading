import logging

PROJECTSPATH = '/Users/chriscollins/Documents/GitHub/football_trading/packages/football_trading/football_trading'
DB_DIR = '/Users/chriscollins/Documents/GitHub/football_trading/db.sqlite'
RECREATE_DB = False

# Credentials required to access the Betfair Exchange API.
BFEX_USER = 'qembet'
BFEX_PASSWORD = 'Double16!'
BFEX_APP_KEY = 'dNfmqo4rsDF6ygJl'
BFEX_CERTS_PATH = '/certs'

FORMATTER = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - "
    "%(funcName)s:%(lineno)d - %(message)s")
LOG_FILE = f"{PROJECTSPATH}/logs/model.log"
